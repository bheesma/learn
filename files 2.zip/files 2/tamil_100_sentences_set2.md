# 100 More Basic Tamil Sentences — SET 2 (New sentences, no repeats)

## 1. Colors (நிறங்கள்)
1. இது சிவப்பு நிறம். – This is red color.
2. வானம் நீல நிறம். – The sky is blue.
3. புல் பச்சை நிறமாக இருக்கிறது. – The grass is green.
4. இது மஞ்சள் நிறம். – This is yellow.
5. பால் வெள்ளை நிறமானது. – Milk is white color.
6. இரவு கருப்பு நிறமானது. – Night is black.
7. இந்த பூ ஊதா நிறம். – This flower is purple.
8. எனக்கு ஆரஞ்சு நிறம் பிடிக்கும். – I like orange color.
9. இது எந்த நிறம்? – What color is this?
10. எனக்கு பல நிறங்கள் பிடிக்கும். – I like many colors.

## 2. Body Parts (உடல் உறுப்புகள்)
11. இது என் தலை. – This is my head.
12. இவை என் கண்கள். – These are my eyes.
13. இது என் மூக்கு. – This is my nose.
14. இது என் வாய். – This is my mouth.
15. இவை என் கைகள். – These are my hands.
16. இவை என் கால்கள். – These are my legs.
17. இது என் காது. – This is my ear.
18. எனக்கு வயிறு வலிக்கிறது. – My stomach hurts.
19. நான் என் கைகளை கழுவுகிறேன். – I wash my hands.
20. என் முடி நீளமானது. – My hair is long.

## 3. Transportation (போக்குவரத்து)
21. நான் பேருந்தில் செல்கிறேன். – I go by bus.
22. அப்பா காரில் ஓட்டுகிறார். – Father drives a car.
23. ரயில் வேகமாகச் செல்கிறது. – The train goes fast.
24. நான் மிதிவண்டி ஓட்டுகிறேன். – I ride a bicycle.
25. விமானம் வானத்தில் பறக்கிறது. – The airplane flies in the sky.
26. படகு தண்ணீரில் மிதக்கிறது. – The boat floats on water.
27. நாங்கள் நடந்து செல்கிறோம். – We walk.
28. ஆட்டோ நிற்கிறது. – The auto stops.
29. சாலையில் நிறைய வண்டிகள் இருக்கின்றன. – There are many vehicles on the road.
30. பேருந்து நிலையம் அருகில் உள்ளது. – The bus stand is nearby.

## 4. Home (வீடு)
31. இது என் வீடு. – This is my house.
32. இது என் அறை. – This is my room.
33. சமையலறையில் அம்மா இருக்கிறாள். – Mother is in the kitchen.
34. கதவை மூடு. – Close the door.
35. ஜன்னலைத் திற. – Open the window.
36. இது என் படுக்கை. – This is my bed.
37. விளக்கை அணை. – Turn off the light.
38. வீட்டில் நிறைய அறைகள் இருக்கின்றன. – There are many rooms in the house.
39. தோட்டத்தில் பூக்கள் உள்ளன. – There are flowers in the garden.
40. நாங்கள் மொட்டை மாடியில் விளையாடுகிறோம். – We play on the terrace.

## 5. Sports & Hobbies (விளையாட்டு & பொழுதுபோக்கு)
41. நான் கிரிக்கெட் விளையாடுகிறேன். – I play cricket.
42. அவன் பந்து எறிகிறான். – He throws the ball.
43. நாங்கள் கால்பந்து விளையாடுகிறோம். – We play football.
44. எனக்கு ஓவியம் வரைய பிடிக்கும். – I like to draw pictures.
45. நான் பாட்டு பாடுகிறேன். – I sing a song.
46. அவள் நடனம் ஆடுகிறாள். – She dances.
47. நான் புத்தகம் படிக்க விரும்புகிறேன். – I like to read books.
48. நாங்கள் நீச்சல் அடிக்கிறோம். – We swim.
49. எனக்கு சித்திரம் வரைவது பிடிக்கும். – I like to paint.
50. நாங்கள் மைதானத்தில் விளையாடுகிறோம். – We play in the ground.

## 6. Health (ஆரோக்கியம்)
51. எனக்கு உடல்நிலை சரியில்லை. – I am not feeling well.
52. எனக்கு காய்ச்சல். – I have a fever.
53. மருத்துவரிடம் செல்வோம். – Let's go to the doctor.
54. மருந்து சாப்பிடு. – Take the medicine.
55. ஓய்வு எடு. – Take rest.
56. தண்ணீர் அதிகமாகக் குடி. – Drink more water.
57. உடற்பயிற்சி செய். – Do exercise.
58. கை கழுவு. – Wash your hands.
59. நன்றாகத் தூங்கு. – Sleep well.
60. நான் இப்போது நலமாக இருக்கிறேன். – I am fine now.

## 7. Seasons & Festivals (பருவங்கள் & பண்டிகைகள்)
61. இது கோடை காலம். – This is summer season.
62. இது மழைக் காலம். – This is rainy season.
63. பொங்கல் ஒரு பெரிய பண்டிகை. – Pongal is a big festival.
64. தீபாவளி விளக்குகளின் திருநாள். – Diwali is the festival of lights.
65. நாங்கள் பண்டிகையை கொண்டாடுகிறோம். – We celebrate the festival.
66. புத்தாண்டு வாழ்த்துக்கள். – Happy New Year.
67. இது பிறந்தநாள். – This is a birthday.
68. நாங்கள் புதிய ஆடை அணிகிறோம். – We wear new clothes.
69. வீட்டில் விருந்தினர்கள் வந்தனர். – Guests came home.
70. பட்டாசு வெடிக்கிறது. – Firecrackers burst.

## 8. Clothes (ஆடைகள்)
71. இது என் சட்டை. – This is my shirt.
72. இது என் பாவாடை. – This is my skirt.
73. நான் காலணி அணிகிறேன். – I wear shoes.
74. இது புதிய ஆடை. – This is a new dress.
75. தொப்பியை அணி. – Wear the cap.
76. இது என் சீருடை. – This is my uniform.
77. ஆடை துவைக்க வேண்டும். – The clothes need to be washed.
78. இது மிகவும் அழகான ஆடை. – This is a very beautiful dress.
79. என் காலணி சிறியது. – My shoe is small.
80. சட்டையை மாற்று. – Change the shirt.

## 9. Numbers & Counting (எண்ணுதல்)
81. ஒன்று, இரண்டு, மூன்று. – One, two, three.
82. நான்கு பேர் இருக்கிறோம். – We are four people.
83. ஐந்து விரல்கள் இருக்கின்றன. – There are five fingers.
84. பத்து ஆப்பிள்கள் இருக்கின்றன. – There are ten apples.
85. இது முதல் நாள். – This is the first day.
86. இது கடைசி பக்கம். – This is the last page.
87. எண்ணு பார். – Count it.
88. இதில் எத்தனை இருக்கின்றன? – How many are there in this?
89. நூறு ரூபாய் கொடு. – Give one hundred rupees.
90. நான் எண்களை நன்றாக அறிவேன். – I know numbers well.

## 10. Commands & Requests (கட்டளைகள் & கோரிக்கைகள்)
91. இங்கே வா. – Come here.
92. அங்கே போ. – Go there.
93. அமைதியாக இரு. – Be quiet.
94. கவனமாகக் கேள். – Listen carefully.
95. இதை எடு. – Take this.
96. இதை வை. – Keep this.
97. சீக்கிரம் வா. – Come quickly.
98. கொஞ்சம் காத்திரு. – Wait a little.
99. இதைச் செய். – Do this.
100. நன்றாகச் செய். – Do it well.
