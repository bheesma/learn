# Tamil Words by Letter (for kids)

**Note on Tamil:** Only these consonants naturally *start* Tamil words: க, ச, த, ந, ப, ம, ய, வ (and loanwords use ர, ல, ட, etc.). Letters like ங, ஞ, ண, ன, ழ, ள, ற almost never appear at the start of a word — they show up in the middle. For those, the words below *contain* the letter rather than start with it.

## உயிர் எழுத்துக்கள் (Vowels)

**அ (a)**
- அம்மா – mother
- அப்பா – father
- அரிசி – rice
- அணில் – squirrel
- அலை – wave
- அடி – foot/hit
- அன்பு – love
- அரசு – government
- அமைதி – peace
- அழகு – beauty

**ஆ (aa)**
- ஆடு – goat
- ஆமை – turtle
- ஆலமரம் – banyan tree
- ஆசை – desire
- ஆடை – clothing
- ஆண் – male
- ஆறு – river/six
- ஆய்வு – research
- ஆசிரியர் – teacher
- ஆபத்து – danger

**இ (i)**
- இலை – leaf
- இரவு – night
- இனிப்பு – sweet
- இசை – music
- இரயில் – train
- இரண்டு – two
- இதயம் – heart
- இளம் – young
- இடம் – place
- இறகு – feather

**ஈ (ee)**
- ஈ – fly (insect)
- ஈரல் – liver
- ஈட்டி – spear
- ஈரம் – wetness
- ஈகை – charity

**உ (u)**
- உப்பு – salt
- உடல் – body
- உணவு – food
- உறவு – relation
- உலகம் – world
- உதடு – lip
- உழவன் – farmer
- உறங்கு – sleep
- உயரம் – height
- உள்ளம் – heart/mind

**ஊ (oo)**
- ஊஞ்சல் – swing
- ஊர் – town
- ஊசி – needle
- ஊமை – mute
- ஊழியர் – employee
- ஊட்டம் – nutrition
- ஊற்று – spring/source
- ஊக்கம் – encouragement

**எ (e)**
- எலி – mouse/rat
- எறும்பு – ant
- எண் – number
- எழுது – write
- எழுத்து – letter (alphabet)
- எடு – take
- எங்கே – where
- எப்போது – when
- எதிர் – opposite/front
- என் – my

**ஏ (ee-long)**
- ஏணி – ladder
- ஏர் – plough
- ஏழு – seven
- ஏக்கர் – acre
- ஏமாற்று – deceive
- ஏற்றம் – rise
- ஏரி – lake
- ஏழை – poor person
- ஏடு – book/manuscript

**ஐ (ai)**
- ஐந்து – five
- ஐஸ் – ice
- ஐயா – sir
- ஐக்கியம் – unity
- ஐம்பது – fifty

**ஒ (o)**
- ஒட்டகம் – camel
- ஒன்று – one
- ஒளி – light
- ஒப்பந்தம் – agreement
- ஒழுங்கு – order/discipline
- ஒலி – sound
- ஒட்டு – glue/stick
- ஒரு – a/one
- ஒப்பு – comparison

**ஓ (oo-long)**
- ஓடு – run / tile
- ஓவியம் – painting
- ஓலை – palm leaf
- ஓநாய் – wolf
- ஓய்வு – rest
- ஓசை – sound
- ஓட்டம் – running
- ஓடை – stream
- ஓட்டுநர் – driver

**ஔ (au)**
- ஔடதம் – medicine
- ஔவையார் – (name of a famous Tamil poet)

**ஃ (aytham)** – This is a special sound, not used to start words. It appears within words like அஃது.

## மெய் எழுத்துக்கள் (Consonants)

**க (ka)**
- கை – hand
- கால் – leg
- கடல் – sea
- கண் – eye
- கடிகாரம் – clock
- கத்தி – knife
- கரடி – bear
- கல் – stone
- காகம் – crow
- கத்தரிக்காய் – brinjal

**ங (nga)** – rarely starts words; appears in the middle:
- மங்கை – young woman
- திங்கள் – Monday/moon
- இளங்கோ – (a name)

**ச (cha/sa)**
- சாதம் – cooked rice
- சட்டை – shirt
- சக்கரம் – wheel
- சூரியன் – sun
- சந்திரன் – moon
- சிங்கம் – lion
- சிறுத்தை – leopard
- சங்கு – conch
- சமையல் – cooking
- சிறகு – wing

**ஞ (nya)** – rarely starts words:
- ஞாயிறு – Sunday/sun
- ஞாபகம் – memory
- ஞானம் – wisdom

**ட (ta - hard)** – mostly loanwords / medial:
- டப்பா – tin/box
- டாக்டர் – doctor
- வண்டு – beetle (contains ட)
- குண்டு – bomb (contains ட)

**ண (Na - retroflex)** – almost never initial; appears in the middle:
- மணி – bell/hour
- பணம் – money
- வீணை – veena (instrument)

**த (tha)**
- தலை – head
- தண்ணீர் – water
- தமிழ் – Tamil
- தட்டு – plate
- தேன் – honey
- தேங்காய் – coconut
- தோட்டம் – garden
- தாத்தா – grandfather
- தங்கம் – gold
- தையல் – sewing

**ந (na)**
- நண்டு – crab
- நாய் – dog
- நண்பன் – friend
- நதி – river
- நிலா – moon
- நாடு – country
- நாக்கு – tongue
- நடனம் – dance
- நரி – fox
- நூல் – thread/book

**ப (pa)**
- பால் – milk
- பசு – cow
- பறவை – bird
- பூ – flower
- பல்லி – lizard
- பாம்பு – snake
- பள்ளி – school
- பணம் – money
- பழம் – fruit
- பாட்டு – song

**ம (ma)**
- மரம் – tree
- மழை – rain
- மீன் – fish
- மனிதன் – human
- மாலை – evening/garland
- முகம் – face
- மேகம் – cloud
- மணி – bell/hour
- முயல் – rabbit
- மகிழ்ச்சி – happiness

**ய (ya)**
- யானை – elephant
- யாழ் – lute
- யார் – who
- யுத்தம் – war
- யோகா – yoga
- யோசனை – idea

**ர (ra)**
- ரயில் – train
- ரோஜா – rose
- ரொட்டி – bread
- ரத்தம் – blood
- ரிக்ஷா – rickshaw

**ல (la)**
- லட்டு – laddu (sweet)
- லாரி – lorry
- லேகியம் – herbal paste

**வ (va)**
- வீடு – house
- வானம் – sky
- வாழை – banana
- விளக்கு – lamp
- வண்டி – vehicle/cart
- வெயில் – sunshine
- வில் – bow
- வளையல் – bangle
- விமானம் – airplane
- வாத்து – duck

**ழ (zha - unique Tamil sound)** – almost never initial; appears in the middle:
- தமிழ் – Tamil
- வாழை – banana
- பழம் – fruit
- வழி – way/path

**ள (La - retroflex)** – almost never initial; appears in the middle:
- வாள் – sword
- தள்ளு – push
- கோள் – planet

**ற (Ra - hard)** – almost never initial; appears in the middle:
- ஆற்று – of the river
- கூற்று – statement
- மாற்று – change

**ன (na - alveolar)** – never starts a word; always middle/end:
- வான் – sky/van
- பொன் – gold
- தேன் – honey
