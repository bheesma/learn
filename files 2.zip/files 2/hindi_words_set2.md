# Hindi Words by Letter — SET 2 (New words, no repeats from Set 1)

## स्वर (Vowels)

**अ (a)**
- अखरोट – walnut
- अचार – pickle
- अदरक – ginger
- अनानास – pineapple
- अटैची – suitcase
- अनाज – grain
- अलार्म घड़ी – alarm clock
- अभिनेता – actor

**आ (aa)**
- आकाश – sky
- आवाज़ – voice/sound
- आंसू – tear
- आजादी – freedom
- आदत – habit
- आलस्य – laziness
- आभूषण – jewelry
- आरती – aarti (prayer ritual)

**इ (i)**
- इच्छा – wish
- इलाज – treatment
- इतिहास – history
- इंटरनेट – internet
- इनकार – refusal
- इंसानियत – humanity

**ई (ee)** – rare letter, a couple more:
- ईमान – faith/integrity
- ईर्ष्या – jealousy

**उ (u)**
- उम्मीद – hope
- उछाल – bounce
- उपयोग – use
- उत्तर – answer/north
- उपनाम – nickname
- उपचार – remedy/treatment

**ऊ (oo)**
- ऊपर – above
- ऊब – boredom

**ऋ (ri)** – no further common words; genuinely rare beyond Set 1.

**ए (e)**
- एकांत – solitude
- एकदम – exactly/at once

**ऐ (ai)** – no further common words beyond Set 1.

**ओ (o)**
- ओढ़नी – shawl

**औ (au)**
- औसत – average

## व्यंजन (Consonants)

**क (ka)**
- कमीज़ – shirt
- कुर्सी – chair
- कागज़ – paper
- करेला – bitter gourd
- केला – banana
- किसान – farmer
- कोयल – cuckoo
- कोट – coat
- कड़ाही – pan/wok
- कंघी – comb

**ख (kha)**
- खीरा – cucumber
- खत – letter (mail)
- खजाना – treasure
- खिलाड़ी – player
- खाट – cot
- खरोंच – scratch

**ग (ga)**
- गाजर – carrot
- गीत – song
- गोभी – cabbage
- गोल – round
- गुलदस्ता – bouquet
- गिलहरी – squirrel
- गंगा – Ganga (river)
- गुफा – cave

**घ (gha)**
- घबराहट – nervousness
- घरेलू – domestic
- घटना – event/incident

**च (cha)**
- चींटी – ant
- चाय – tea
- चांदी – silver
- चोर – thief
- चूना – lime
- चमेली – jasmine
- चोटी – braid/peak

**छ (chha)**
- छज्जा – ledge
- छक्का – six (cricket)
- छिलका – peel

**ज (ja)**
- जूस – juice
- जीभ – tongue
- जंगली – wild
- जासूस – detective
- जोकर – joker
- जुराब – sock
- जन्म – birth

**झ (jha)**
- झबरा – shaggy (dog)
- झलक – glimpse
- झूठ – lie

**ट (Ta)**
- टहलना – to stroll
- टुकड़ा – piece
- टापू – island
- टोली – group

**ठ (Tha)**
- ठग – cheat/con person
- ठिकाना – location/whereabouts

**ड (Da)**
- डायनासोर – dinosaur
- डकैत – bandit
- डेरा – camp

**ढ (Dha)**
- ढूंढना – to search
- ढलना – to mold/cast

**ण (Na)** – medial examples:
- गुण – quality/virtue
- प्रण – vow

**त (ta)**
- तराज़ू – scale/balance
- तस्वीर – picture
- तूफान – storm
- तंबू – tent
- तख्त – throne/plank

**थ (tha)**
- थप्पड़ – slap
- थूक – spit

**द (da)**
- दीया – lamp/diya
- दुनिया – world
- दोस्त – friend
- दराज़ – drawer
- दस्तक – knock

**ध (dha)**
- ध्यान – attention/meditation
- धमाका – explosion
- धुरी – axis

**न (na)**
- नमूना – sample
- निशान – mark/sign
- नक्शा – map
- नानी – maternal grandmother
- नाना – maternal grandfather
- नारा – slogan

**प (pa)**
- पतझड़ – autumn
- पहचान – identity
- पर्दा – curtain
- पसीना – sweat
- पिचकारी – water gun (Holi)
- पालना – cradle
- पड़ोसी – neighbor

**फ (pha)**
- फुहार – spray
- फफूंद – mold/fungus
- फांक – slice

**ब (ba)**
- बादाम – almond
- बटन – button
- बंदूक – gun
- बर्फ – ice/snow
- बहन – sister

**भ (bha)**
- भूख – hunger
- भेड़िया – wolf
- भजन – devotional song

**म (ma)**
- मूली – radish
- मुकुट – crown
- मंदिर – temple
- मजदूर – laborer
- मुस्कान – smile
- मदद – help

**य (ya)**
- यमुना – Yamuna (river)
- यकीन – belief/trust

**र (ra)**
- रंगोली – rangoli
- राजकुमार – prince
- रेगिस्तान – desert
- रीछ – bear
- राख – ash

**ल (la)**
- लस्सी – lassi (drink)
- लहर – wave
- लगाम – rein
- लालच – greed

**व (va)**
- वादा – promise
- वजन – weight
- विद्यार्थी – student
- वर्दी – uniform

**श (sha)**
- शक्कर – sugar
- शरारत – mischief
- शिशु – infant
- शहर – city

**ष (Sha)** – no further common words; genuinely rare.

**स (sa)**
- सपना – dream
- सड़क – road
- संगीत – music
- सुबह – morning
- सर्दी – cold/winter
- सुगंध – fragrance

**ह (ha)**
- हल्दी – turmeric
- हिम्मत – courage
- हीरा – diamond
- हड्डी – bone

**क्ष (ksha)**
- क्षितिज – horizon

**त्र (tra)** – no further common/simple words; genuinely rare beyond Set 1.

**ज्ञ (gya/jna)** – no further common words; only ज्ञान/ज्ञानी are in everyday use.
