# 100 Basic Hindi Sentences for Kids

## 1. Greetings & Politeness (नमस्कार व शिष्टाचार)
1. नमस्ते। – Hello.
2. धन्यवाद। – Thank you.
3. कृपया बैठिए। – Please sit down.
4. माफ़ कीजिए। – Sorry / Excuse me.
5. सुप्रभात। – Good morning.
6. शुभ रात्रि। – Good night.
7. आप कैसे हैं? – How are you?
8. मैं ठीक हूं। – I am fine.
9. आपका नाम क्या है? – What is your name?
10. मेरा नाम राहुल है। – My name is Rahul.

## 2. Family & People (परिवार)
11. यह मेरी मां है। – This is my mother.
12. यह मेरे पिताजी हैं। – This is my father.
13. वह मेरा भाई है। – He is my brother.
14. वह मेरी बहन है। – She is my sister.
15. मेरी एक छोटी बहन है। – I have a younger sister.
16. मेरे दादाजी बूढ़े हैं। – My grandfather is old.
17. मेरी दादी खाना बनाती हैं। – My grandmother cooks food.
18. हम एक परिवार हैं। – We are a family.
19. मेरा दोस्त स्कूल आता है। – My friend comes to school.
20. वे मेरे शिक्षक हैं। – He is my teacher.

## 3. Daily Routine (दिनचर्या)
21. मैं सुबह उठता हूं। – I wake up in the morning.
22. मैं दांत साफ करता हूं। – I brush my teeth.
23. मैं नहाता हूं। – I take a bath.
24. मैं नाश्ता करता हूं। – I eat breakfast.
25. मैं स्कूल जाता हूं। – I go to school.
26. मैं दोपहर का खाना खाता हूं। – I eat lunch.
27. मैं खेलता हूं। – I play.
28. मैं गृहकार्य करता हूं। – I do homework.
29. मैं रात का खाना खाता हूं। – I eat dinner.
30. मैं रात को सोता हूं। – I sleep at night.

## 4. School (स्कूल)
31. यह मेरा स्कूल है। – This is my school.
32. मैं पहली कक्षा में पढ़ता हूं। – I study in first grade.
33. मुझे हिंदी पसंद है। – I like Hindi.
34. यह मेरी किताब है। – This is my book.
35. मुझे एक पेन चाहिए। – I need a pen.
36. शिक्षक पाठ पढ़ाते हैं। – The teacher teaches the lesson.
37. हम कक्षा में हैं। – We are in the classroom.
38. स्कूल की घंटी बजती है। – The school bell rings.
39. मैं अच्छे से पढ़ता हूं। – I study well.
40. आज छुट्टी है। – Today is a holiday.

## 5. Food & Drink (खाना-पीना)
41. मुझे भूख लगी है। – I am hungry.
42. मुझे पानी दो। – Give me water.
43. यह चावल स्वादिष्ट है। – This rice is tasty.
44. मुझे फल पसंद हैं। – I like fruit.
45. मां रोटी बनाती है। – Mother makes roti.
46. मैं दूध पीता हूं। – I drink milk.
47. यह मीठा है। – This is sweet.
48. यह सब्ज़ी ताज़ा है। – This vegetable is fresh.
49. चलो साथ में खाना खाएं। – Let's eat together.
50. मुझे प्यास लगी है। – I am thirsty.

## 6. Animals & Nature (जानवर व प्रकृति)
51. कुत्ता भौंकता है। – The dog barks.
52. बिल्ली दूध पीती है। – The cat drinks milk.
53. पक्षी उड़ता है। – The bird flies.
54. पेड़ पर फल हैं। – There are fruits on the tree.
55. आसमान में चांद है। – There is a moon in the sky.
56. सूरज सुबह उगता है। – The sun rises in the morning.
57. बारिश हो रही है। – It is raining.
58. फूल सुंदर हैं। – The flowers are beautiful.
59. हाथी बड़ा होता है। – The elephant is big.
60. मछली पानी में तैरती है। – The fish swims in water.

## 7. Weather & Time (मौसम व समय)
61. आज बहुत धूप है। – It is very sunny today.
62. आज ठंड है। – It is cold today.
63. अभी सुबह का समय है। – It is morning now.
64. अभी क्या समय हुआ है? – What is the time now?
65. आज सोमवार है। – Today is Monday.
66. कल रविवार है। – Tomorrow is Sunday.
67. यह महीना जनवरी है। – This month is January.
68. आसमान में बादल हैं। – The sky is cloudy.
69. हवा चल रही है। – The wind is blowing.
70. आज अच्छा दिन है। – Today is a good day.

## 8. Feelings (भावनाएं)
71. मैं खुश हूं। – I am happy.
72. मैं दुखी हूं। – I am sad.
73. मुझे डर लग रहा है। – I am scared.
74. मैं थका हुआ हूं। – I am tired.
75. मुझे गुस्सा आ रहा है। – I am angry.
76. मैं तुमसे प्यार करता हूं। – I love you.
77. मुझे यह पसंद है। – I like this.
78. मुझे यह पसंद नहीं है। – I don't like this.
79. मैं ठीक हूं। – I am fine.
80. तुम अच्छे बच्चे हो। – You are a good child.

## 9. Numbers & Shopping (संख्या व खरीदारी)
81. यह कितने का है? – How much is this?
82. मुझे यह चाहिए। – I want this.
83. यह बहुत महंगा है। – This is very expensive.
84. यह सस्ता है। – This is cheap.
85. एक किलो चावल दीजिए। – Give one kilo of rice.
86. मुझे दो सेब चाहिए। – I want two apples.
87. पैसे यहां हैं। – Here is the money.
88. दुकान खुली है। – The shop is open.
89. दुकान बंद है। – The shop is closed.
90. चलो बाज़ार चलते हैं। – Let's go to the market.

## 10. Common Questions (सामान्य प्रश्न)
91. यह क्या है? – What is this?
92. तुम कहां जा रहे हो? – Where are you going?
93. यह किसका है? – Whose is this?
94. तुम क्या कर रहे हो? – What are you doing?
95. कल क्या होगा? – What will happen tomorrow?
96. तुम कब आओगे? – When will you come?
97. तुम क्यों रो रहे हो? – Why are you crying?
98. तुम कौन हो? – Who are you?
99. यह कैसे काम करता है? – How does this work?
100. हम कहां हैं? – Where are we?
