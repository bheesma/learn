# 100 Basic Tamil Sentences for Kids

## 1. Greetings & Politeness (வணக்கம் & பண்பு)
1. வணக்கம். – Hello.
2. நன்றி. – Thank you.
3. தயவு செய்து உட்காருங்கள். – Please sit down.
4. மன்னிக்கவும். – Sorry / Excuse me.
5. நல்ல காலை வணக்கம். – Good morning.
6. நல்ல இரவு. – Good night.
7. எப்படி இருக்கிறீர்கள்? – How are you?
8. நான் நன்றாக இருக்கிறேன். – I am fine.
9. உங்கள் பெயர் என்ன? – What is your name?
10. என் பெயர் ராமு. – My name is Ramu.

## 2. Family & People (குடும்பம்)
11. இது என் அம்மா. – This is my mother.
12. இது என் அப்பா. – This is my father.
13. அவன் என் தம்பி. – He is my younger brother.
14. அவள் என் அக்கா. – She is my elder sister.
15. எனக்கு ஒரு தங்கை இருக்கிறாள். – I have a younger sister.
16. என் தாத்தா வயதானவர். – My grandfather is old.
17. என் பாட்டி சமையல் செய்கிறாள். – My grandmother cooks.
18. நாங்கள் ஒரு குடும்பம். – We are a family.
19. என் நண்பன் பள்ளிக்கு வருகிறான். – My friend comes to school.
20. அவர் என் ஆசிரியர். – He is my teacher.

## 3. Daily Routine (தினசரி வேலைகள்)
21. நான் காலையில் எழுகிறேன். – I wake up in the morning.
22. நான் பல் துலக்குகிறேன். – I brush my teeth.
23. நான் குளிக்கிறேன். – I take a bath.
24. நான் காலை உணவு சாப்பிடுகிறேன். – I eat breakfast.
25. நான் பள்ளிக்குச் செல்கிறேன். – I go to school.
26. நான் மதிய உணவு சாப்பிடுகிறேன். – I eat lunch.
27. நான் விளையாடுகிறேன். – I play.
28. நான் வீட்டுப்பாடம் செய்கிறேன். – I do homework.
29. நான் இரவு உணவு சாப்பிடுகிறேன். – I eat dinner.
30. நான் இரவு தூங்குகிறேன். – I sleep at night.

## 4. School (பள்ளி)
31. இது என் பள்ளி. – This is my school.
32. நான் ஒன்றாம் வகுப்பில் படிக்கிறேன். – I study in first standard.
33. எனக்கு தமிழ் பிடிக்கும். – I like Tamil.
34. இது என் புத்தகம். – This is my book.
35. எனக்கு ஒரு பேனா தேவை. – I need a pen.
36. ஆசிரியர் பாடம் சொல்லிக் கொடுக்கிறார். – The teacher teaches the lesson.
37. நாங்கள் வகுப்பறையில் இருக்கிறோம். – We are in the classroom.
38. பள்ளி மணி அடிக்கிறது. – The school bell rings.
39. நான் நன்றாகப் படிக்கிறேன். – I study well.
40. இன்று விடுமுறை. – Today is a holiday.

## 5. Food & Drink (உணவு)
41. எனக்கு பசி எடுக்கிறது. – I am hungry.
42. தண்ணீர் கொடுங்கள். – Give me water.
43. இந்த சாதம் சுவையாக இருக்கிறது. – This rice is tasty.
44. எனக்கு பழம் பிடிக்கும். – I like fruit.
45. அம்மா தோசை சுடுகிறாள். – Mother makes dosa.
46. நான் பால் குடிக்கிறேன். – I drink milk.
47. இது இனிப்பு. – This is sweet.
48. இந்த காய்கறி புதியது. – This vegetable is fresh.
49. நாம் சேர்ந்து சாப்பிடுவோம். – Let's eat together.
50. எனக்கு தாகமாக இருக்கிறது. – I am thirsty.

## 6. Animals & Nature (விலங்குகள் & இயற்கை)
51. நாய் குரைக்கிறது. – The dog barks.
52. பூனை பாலை குடிக்கிறது. – The cat drinks milk.
53. பறவை பறக்கிறது. – The bird flies.
54. மரத்தில் பழங்கள் இருக்கின்றன. – There are fruits on the tree.
55. வானத்தில் நிலவு இருக்கிறது. – There is a moon in the sky.
56. சூரியன் காலையில் உதிக்கிறது. – The sun rises in the morning.
57. மழை பெய்கிறது. – It is raining.
58. பூக்கள் அழகாக இருக்கின்றன. – The flowers are beautiful.
59. யானை பெரியது. – The elephant is big.
60. மீன் தண்ணீரில் நீந்துகிறது. – The fish swims in water.

## 7. Weather & Time (வானிலை & நேரம்)
61. இன்று வெயில் அதிகம். – It is very sunny today.
62. இன்று குளிர்ச்சியாக இருக்கிறது. – It is cold today.
63. இப்போது காலை நேரம். – It is morning now.
64. இப்போது நேரம் என்ன? – What is the time now?
65. இன்று திங்கட்கிழமை. – Today is Monday.
66. நாளை ஞாயிற்றுக்கிழமை. – Tomorrow is Sunday.
67. இது தை மாதம். – This is the month of Thai.
68. வானம் மேகமூட்டமாக இருக்கிறது. – The sky is cloudy.
69. காற்று வீசுகிறது. – The wind is blowing.
70. இன்று நல்ல நாள். – Today is a good day.

## 8. Feelings (உணர்வுகள்)
71. நான் மகிழ்ச்சியாக இருக்கிறேன். – I am happy.
72. நான் சோகமாக இருக்கிறேன். – I am sad.
73. எனக்கு பயமாக இருக்கிறது. – I am scared.
74. நான் சோர்வாக இருக்கிறேன். – I am tired.
75. எனக்கு கோபமாக இருக்கிறது. – I am angry.
76. நான் உன்னை நேசிக்கிறேன். – I love you.
77. இது எனக்குப் பிடிக்கும். – I like this.
78. இது எனக்குப் பிடிக்காது. – I don't like this.
79. நான் நலமாக இருக்கிறேன். – I am fine.
80. நீ நல்லவன். – You are a good boy.

## 9. Numbers & Shopping (எண்கள் & கடை)
81. இது எவ்வளவு? – How much is this?
82. எனக்கு இது வேண்டும். – I want this.
83. இது மிகவும் விலை உயர்ந்தது. – This is very expensive.
84. இது மலிவானது. – This is cheap.
85. ஒரு கிலோ அரிசி கொடுங்கள். – Give one kilo of rice.
86. எனக்கு இரண்டு ஆப்பிள் வேண்டும். – I want two apples.
87. பணம் இங்கே இருக்கிறது. – Here is the money.
88. கடை திறந்திருக்கிறது. – The shop is open.
89. கடை மூடியிருக்கிறது. – The shop is closed.
90. நாம் சந்தைக்குப் போவோம். – Let's go to the market.

## 10. Common Questions (கேள்விகள்)
91. இது என்ன? – What is this?
92. நீ எங்கே போகிறாய்? – Where are you going?
93. இது யாருடையது? – Whose is this?
94. நீ என்ன செய்கிறாய்? – What are you doing?
95. நாளை என்ன நடக்கும்? – What will happen tomorrow?
96. நீ எப்போது வருவாய்? – When will you come?
97. ஏன் அழுகிறாய்? – Why are you crying?
98. நீ யார்? – Who are you?
99. இது எப்படி வேலை செய்கிறது? – How does this work?
100. நாம் எங்கே இருக்கிறோம்? – Where are we?
