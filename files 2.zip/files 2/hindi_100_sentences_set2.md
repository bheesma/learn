# 100 More Basic Hindi Sentences — SET 2 (New sentences, no repeats)

## 1. Colors (रंग)
1. यह लाल रंग है। – This is red color.
2. आसमान नीला है। – The sky is blue.
3. घास हरी है। – The grass is green.
4. यह पीला रंग है। – This is yellow.
5. दूध सफेद होता है। – Milk is white.
6. रात काली होती है। – Night is black.
7. यह फूल बैंगनी है। – This flower is purple.
8. मुझे नारंगी रंग पसंद है। – I like orange color.
9. यह कौन सा रंग है? – What color is this?
10. मुझे कई रंग पसंद हैं। – I like many colors.

## 2. Body Parts (शरीर के अंग)
11. यह मेरा सिर है। – This is my head.
12. ये मेरी आंखें हैं। – These are my eyes.
13. यह मेरी नाक है। – This is my nose.
14. यह मेरा मुंह है। – This is my mouth.
15. ये मेरे हाथ हैं। – These are my hands.
16. ये मेरे पैर हैं। – These are my legs.
17. यह मेरा कान है। – This is my ear.
18. मेरे पेट में दर्द है। – My stomach hurts.
19. मैं अपने हाथ धोता हूं। – I wash my hands.
20. मेरे बाल लंबे हैं। – My hair is long.

## 3. Transportation (यातायात)
21. मैं बस से जाता हूं। – I go by bus.
22. पापा कार चलाते हैं। – Father drives a car.
23. ट्रेन तेज़ चलती है। – The train goes fast.
24. मैं साइकिल चलाता हूं। – I ride a bicycle.
25. हवाई जहाज़ आसमान में उड़ता है। – The airplane flies in the sky.
26. नाव पानी में तैरती है। – The boat floats on water.
27. हम पैदल चलते हैं। – We walk.
28. ऑटो रुकता है। – The auto stops.
29. सड़क पर बहुत गाड़ियां हैं। – There are many vehicles on the road.
30. बस स्टैंड पास में है। – The bus stand is nearby.

## 4. Home (घर)
31. यह मेरा घर है। – This is my house.
32. यह मेरा कमरा है। – This is my room.
33. रसोई में मां हैं। – Mother is in the kitchen.
34. दरवाज़ा बंद करो। – Close the door.
35. खिड़की खोलो। – Open the window.
36. यह मेरा बिस्तर है। – This is my bed.
37. लाइट बंद करो। – Turn off the light.
38. घर में कई कमरे हैं। – There are many rooms in the house.
39. बगीचे में फूल हैं। – There are flowers in the garden.
40. हम छत पर खेलते हैं। – We play on the terrace.

## 5. Sports & Hobbies (खेल व शौक)
41. मैं क्रिकेट खेलता हूं। – I play cricket.
42. वह गेंद फेंकता है। – He throws the ball.
43. हम फुटबॉल खेलते हैं। – We play football.
44. मुझे चित्र बनाना पसंद है। – I like to draw pictures.
45. मैं गाना गाता हूं। – I sing a song.
46. वह नाचती है। – She dances.
47. मुझे किताबें पढ़ना पसंद है। – I like reading books.
48. हम तैरते हैं। – We swim.
49. मुझे पेंटिंग करना पसंद है। – I like painting.
50. हम मैदान में खेलते हैं। – We play in the ground.

## 6. Health (स्वास्थ्य)
51. मेरी तबीयत ठीक नहीं है। – I am not feeling well.
52. मुझे बुखार है। – I have a fever.
53. चलो डॉक्टर के पास चलते हैं। – Let's go to the doctor.
54. दवा खाओ। – Take the medicine.
55. आराम करो। – Take rest.
56. ज्यादा पानी पियो। – Drink more water.
57. व्यायाम करो। – Do exercise.
58. हाथ धो लो। – Wash your hands.
59. अच्छे से सो जाओ। – Sleep well.
60. अब मैं ठीक हूं। – I am fine now.

## 7. Seasons & Festivals (मौसम व त्यौहार)
61. यह गर्मी का मौसम है। – This is summer season.
62. यह बारिश का मौसम है। – This is rainy season.
63. होली एक बड़ा त्यौहार है। – Holi is a big festival.
64. दिवाली रोशनी का त्यौहार है। – Diwali is the festival of lights.
65. हम त्यौहार मनाते हैं। – We celebrate the festival.
66. नया साल मुबारक हो। – Happy New Year.
67. आज जन्मदिन है। – Today is a birthday.
68. हम नए कपड़े पहनते हैं। – We wear new clothes.
69. घर में मेहमान आए। – Guests came home.
70. पटाखे फूट रहे हैं। – Firecrackers are bursting.

## 8. Clothes (कपड़े)
71. यह मेरी शर्ट है। – This is my shirt.
72. यह मेरी स्कर्ट है। – This is my skirt.
73. मैं जूते पहनता हूं। – I wear shoes.
74. यह नया कपड़ा है। – This is a new dress.
75. टोपी पहनो। – Wear the cap.
76. यह मेरी वर्दी है। – This is my uniform.
77. कपड़े धोने हैं। – The clothes need to be washed.
78. यह बहुत सुंदर कपड़ा है। – This is a very beautiful dress.
79. मेरा जूता छोटा है। – My shoe is small.
80. शर्ट बदलो। – Change the shirt.

## 9. Numbers & Counting (गिनती)
81. एक, दो, तीन। – One, two, three.
82. हम चार लोग हैं। – We are four people.
83. पांच उंगलियां होती हैं। – There are five fingers.
84. दस सेब हैं। – There are ten apples.
85. यह पहला दिन है। – This is the first day.
86. यह आखिरी पन्ना है। – This is the last page.
87. गिनती करो। – Count it.
88. इसमें कितने हैं? – How many are there in this?
89. सौ रुपये दो। – Give one hundred rupees.
90. मुझे गिनती अच्छे से आती है। – I know numbers well.

## 10. Commands & Requests (आदेश व अनुरोध)
91. यहां आओ। – Come here.
92. वहां जाओ। – Go there.
93. चुप रहो। – Be quiet.
94. ध्यान से सुनो। – Listen carefully.
95. इसे लो। – Take this.
96. इसे रखो। – Keep this.
97. जल्दी आओ। – Come quickly.
98. थोड़ा रुको। – Wait a little.
99. यह करो। – Do this.
100. अच्छे से करो। – Do it well.
