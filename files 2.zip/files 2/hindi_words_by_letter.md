# Hindi Words by Letter (for kids)

## स्वर (Vowels)

**अ (a)**
- अनार – pomegranate
- अंगूर – grape
- अलमारी – cupboard
- अंडा – egg
- अखबार – newspaper
- अस्पताल – hospital
- अध्यापक – teacher
- अमरूद – guava
- अजगर – python
- अंगूठा – thumb

**आ (aa)**
- आम – mango
- आग – fire
- आसमान – sky
- आंख – eye
- आलू – potato
- आदमी – man
- आटा – flour
- आईना – mirror
- आंगन – courtyard
- आराम – rest

**इ (i)**
- इमली – tamarind
- इंसान – human
- इमारत – building
- इंजन – engine
- इशारा – signal
- इलायची – cardamom
- इत्र – perfume
- इनाम – reward
- इंद्रधनुष – rainbow
- इस्तरी – (flat) iron

**ई (ee)**
- ईख – sugarcane
- ईद – Eid
- ईमानदार – honest
- ईश्वर – God
- ईंट – brick
- ईंधन – fuel

**उ (u)**
- उल्लू – owl
- उंगली – finger
- उड़ान – flight
- उपहार – gift
- उस्तरा – razor
- उधार – loan/credit
- उपाय – remedy
- उत्सव – festival
- उबासी – yawn
- उपवास – fasting

**ऊ (oo)**
- ऊंट – camel
- ऊन – wool
- ऊंचाई – height
- ऊर्जा – energy
- ऊधम – mischief

**ऋ (ri)** – rare letter, very few words:
- ऋषि – sage
- ऋतु – season
- ऋण – debt

**ए (e)**
- एक – one
- एड़ी – heel
- एकता – unity
- एहसान – favor
- एप्रन – apron

**ऐ (ai)**
- ऐनक – spectacles
- ऐसा – like this
- ऐतिहासिक – historical

**ओ (o)**
- ओस – dew
- ओखली – mortar (for grinding)
- ओर – direction
- ओला – hailstone

**औ (au)**
- औरत – woman
- औजार – tool
- औषधि – medicine
- औलाद – offspring

**अं (anusvara, am/an)**
- अंगूठी – ring
- अंडा – egg
- अंधेरा – darkness

**अः (visarga)** – rarely used to start common words; appears in Sanskrit-origin words like दुःख (sorrow).

## व्यंजन (Consonants)

**क (ka)**
- कमल – lotus
- कपड़ा – cloth
- किताब – book
- कुत्ता – dog
- कान – ear
- कमरा – room
- कछुआ – turtle
- कील – nail
- कबूतर – pigeon
- कलम – pen

**ख (kha)**
- खरगोश – rabbit
- खिड़की – window
- खाना – food
- खरबूजा – muskmelon
- खेत – field
- खिलौना – toy
- खजूर – date (fruit)
- खटमल – bedbug
- खिचड़ी – khichdi

**ग (ga)**
- गाय – cow
- गमला – flowerpot
- गाड़ी – car/vehicle
- गुड़िया – doll
- गिलास – glass
- गधा – donkey
- गुब्बारा – balloon
- गेंद – ball
- गुलाब – rose
- गन्ना – sugarcane

**घ (gha)**
- घर – house
- घड़ी – watch/clock
- घोड़ा – horse
- घास – grass
- घंटी – bell
- घी – ghee
- घोंसला – nest
- घुटना – knee
- घूमना – to roam

**ङ (nga)** – almost never starts a Hindi word; the sound appears inside words (e.g., गंगा has a similar nasal sound). No common standalone examples for kids.

**च (cha)**
- चम्मच – spoon
- चश्मा – glasses
- चाबी – key
- चिड़िया – bird
- चांद – moon
- चूहा – mouse
- चप्पल – slipper
- चाकू – knife
- चटाई – mat
- चूल्हा – stove

**छ (chha)**
- छाता – umbrella
- छत – roof
- छिपकली – lizard
- छुट्टी – holiday
- छड़ी – stick
- छाया – shadow
- छल्ला – ring
- छपाई – printing
- छोटा – small

**ज (ja)**
- जंगल – forest
- जहाज़ – ship
- जूता – shoe
- जल – water
- जादू – magic
- जिराफ़ – giraffe
- जामुन – java plum
- जलेबी – jalebi
- जेब – pocket
- जन्मदिन – birthday

**झ (jha)**
- झरना – waterfall
- झूला – swing
- झंडा – flag
- झाड़ू – broom
- झील – lake
- झोपड़ी – hut
- झगड़ा – fight
- झाड़ी – bush
- झुमका – earring
- झींगा – shrimp

**ञ (nya)** – almost never used alone; mainly appears in the conjunct ज्ञ (jña). Not a common starting letter for kids' words.

**ट (Ta)**
- टमाटर – tomato
- टोपी – hat
- टेबल – table
- टोकरी – basket
- टिकट – ticket
- टहनी – twig
- टीवी – TV
- टक्कर – collision
- टांग – leg
- टूथब्रश – toothbrush

**ठ (Tha)**
- ठंड – cold
- ठेला – cart
- ठोकर – stumble
- ठाकुर – lord/title
- ठीकरा – shard
- ठहराव – pause/stop

**ड (Da)**
- डिब्बा – box
- डाकिया – postman
- डर – fear
- डॉक्टर – doctor
- डमरू – small drum
- डाल – branch
- डायरी – diary
- डोर – string
- डंडा – stick
- डेस्क – desk

**ढ (Dha)**
- ढोल – drum
- ढक्कन – lid
- ढाल – shield
- ढेर – heap
- ढलान – slope

**ण (Na - retroflex)** – rarely starts words; appears in the middle:
- गणित – mathematics
- वीणा – veena (instrument)
- हिरण – deer

**त (ta)**
- तारा – star
- तकिया – pillow
- तितली – butterfly
- तरबूज – watermelon
- तालाब – pond
- तोता – parrot
- तार – wire
- तलवार – sword
- ताला – lock
- तीर – arrow

**थ (tha)**
- थाली – plate
- थैला – bag
- थकान – tiredness
- थर्मस – thermos
- थाना – police station

**द (da)**
- दरवाज़ा – door
- दूध – milk
- दवा – medicine
- दीपक – lamp
- दाल – lentils
- दांत – tooth
- दिवाली – Diwali
- दर्पण – mirror
- दस्ताना – glove
- दीवार – wall

**ध (dha)**
- धनुष – bow
- धागा – thread
- धुआं – smoke
- धरती – earth
- धोबी – washerman
- धूप – sunlight
- धान – paddy
- ध्वज – flag
- धोखा – deceit
- धुंध – fog

**न (na)**
- नल – tap
- नाव – boat
- नदी – river
- नारियल – coconut
- नमक – salt
- नाक – nose
- नींबू – lemon
- नाच – dance
- नोट – note
- नाखून – (finger)nail

**प (pa)**
- पतंग – kite
- पहाड़ – mountain
- पेड़ – tree
- पानी – water
- पंखा – fan
- पुस्तक – book
- पत्ता – leaf
- पहिया – wheel
- पौधा – plant
- पतंगा – moth

**फ (pha)**
- फल – fruit
- फूल – flower
- फुटबॉल – football
- फर्श – floor
- फावड़ा – spade
- फसल – crop
- फोन – phone
- फीता – ribbon/lace
- फव्वारा – fountain

**ब (ba)**
- बकरी – goat
- बत्तख – duck
- बगीचा – garden
- बादल – cloud
- बंदर – monkey
- बर्तन – utensil
- बल्ब – bulb
- बच्चा – child
- बिल्ली – cat
- बारिश – rain

**भ (bha)**
- भालू – bear
- भेड़ – sheep
- भवन – building
- भोजन – food
- भाई – brother
- भूकंप – earthquake
- भिंडी – okra
- भार – weight
- भाला – spear

**म (ma)**
- मछली – fish
- मकान – house
- मोर – peacock
- मक्खी – fly
- मेज़ – table
- मटर – peas
- मुर्गी – hen
- माला – garland
- मौसम – weather
- मशीन – machine

**य (ya)**
- यार – friend (casual)
- युद्ध – war
- यात्रा – journey
- यज्ञ – sacrifice/ritual
- यंत्र – machine/instrument
- योग – yoga

**र (ra)**
- रथ – chariot
- रस्सी – rope
- राजा – king
- रोटी – bread
- रंग – color
- रेल – train
- रात – night
- रुमाल – handkerchief
- रबर – rubber
- राखी – rakhi

**ल (la)**
- लड़का – boy
- लोमड़ी – fox
- लालटेन – lantern
- लकड़ी – wood
- लट्टू – spinning top
- लहसुन – garlic
- लिफाफा – envelope
- लोटा – small water pot
- लंगूर – langur (monkey)

**व (va)**
- वन – forest
- वृक्ष – tree
- विमान – airplane
- वर्षा – rain
- वस्त्र – clothes
- वानर – monkey
- वाहन – vehicle
- वेतन – salary
- विद्यालय – school

**श (sha)**
- शेर – lion
- शहद – honey
- शर्ट – shirt
- शलगम – turnip
- शंख – conch
- शादी – wedding
- शतरंज – chess
- शिकार – hunt
- शीशा – mirror/glass
- शाखा – branch

**ष (Sha - retroflex)** – rare, mostly in conjunct/formal words:
- षटकोण – hexagon
- षड्यंत्र – conspiracy

**स (sa)**
- सेब – apple
- सूरज – sun
- साइकिल – bicycle
- सांप – snake
- समुद्र – ocean
- सब्ज़ी – vegetable
- सितारा – star
- संतरा – orange
- सुई – needle
- समय – time

**ह (ha)**
- हाथी – elephant
- हवा – air
- हिरण – deer
- हंस – swan
- हथौड़ा – hammer
- हाथ – hand
- होठ – lip
- हल – plough
- हरा – green

**क्ष (ksha - conjunct)**
- क्षेत्र – area
- क्षमा – forgiveness
- क्षण – moment

**त्र (tra - conjunct)**
- त्रिकोण – triangle
- त्रिशूल – trident
- त्रुटि – error

**ज्ञ (gya/jna - conjunct)**
- ज्ञान – knowledge
- ज्ञानी – wise person
